import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bootstrap-form',
  templateUrl: './bootstrap-form.component.html',
  styleUrls: ['./bootstrap-form.component.sass']
})
export class BootstrapFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
